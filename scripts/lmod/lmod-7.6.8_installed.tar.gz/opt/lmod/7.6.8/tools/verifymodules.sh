#! /bin/bash

export PATH=/bin:/usr/bin
source /etc/profile.d/modules.sh

# Git list of files
modules=`module --terse avail 2>&1 | tail -n+2 | grep -v "/opt"`

# Make Temp file
TMP=`mktemp`

SUCCESS=true

for module in $modules; do

	module show $module 2> $TMP

	# Check to see if module is even able to load, syntax errors, etc
	if [[ $? -ne 0 ]]; then
		cat $TMP
		echo
		SUCCESS=false
		continue
	fi

	# Examine module for loads and check validity
	retired=false
	for l in `grep "^load" $TMP | awk '{ print $2 }'`; do
		if [[ $l == "retired" ]]; then
			retired=true
		fi
		# Try invoking module
		if [[ $retired == true ]]; then
                        module load retired 2> /dev/null;  module show $l 2> /dev/null; module unload retired 2> /dev/null
                else
                        module show $l 2> /dev/null
                fi
		if [[ $? -ne 0 ]]; then
			echo $module:
			echo "Invalid load: $l"
			echo
			SUCCESS=false
		fi
	done

	# Check paths
	for p in `cat $TMP | egrep "(^setenv|^prepend_path|^append_path)" | awk -F\" '{ print $2 }' | grep -v '%' | grep -v '\\$'`; do
		for path in `echo $p | tr ':' '\n'`; do
			# Is this a path?
			if [[ $path =~ ^/ ]]; then
				if [[  ! -e $path ]]; then
					# Ignore permission denied errors. We can't really check these.
					ls $path 2>&1 /dev/null | grep -q "Permission denied";
					if [[ $? -ne 0 ]]; then
						echo $module:
						echo "Invalid path: $path"
						SUCCESS=false
						echo
					fi
				fi
			fi
		done
	done
done

rm $TMP

if [ "$SUCCESS" = false ] ; then
	exit 1
fi
exit 0
